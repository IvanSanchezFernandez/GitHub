####Copyleft Ivan Sanchez Fernandez 2016

# ui.R
library(shiny)
library(ggplot2)
# App appearance
ui <- fluidPage(
  tags$br(),
  tags$strong("COST-EFFECTIVENESS OF RESCUE MEDICATIONS FOR PEDIATRIC STATUS EPILEPTICUS"),
  tags$br(),
  tags$br(),
  tags$strong("Explore how different inputs modify cost-effectiveness"),
  tags$br(),
  tags$header("Remember to enter appropriate inputs into the model: proportions should go from 0 to 1, the cost of No medication should be 0, and the rest of the costs cannot be negative. With inappropriate inputs the model will return inappropriate outputs or errors"),
  tags$br(),
  
  sidebarLayout(
    sidebarPanel(
  fluidRow(

    column(6,
           # Title
           tags$br(),
           tags$br(),
           tags$strong("INPUT"),    
           tags$br(),
           tags$br(),
           tags$br(),
           tags$br(),
           tags$strong("COST ($)"),
           tags$br(),
           tags$br(),
           tags$br(),
           tags$br(),
  ## INPUTS
  # Input cost of rescue medications
  textInput(inputId = "c.Nomed",
               label = "No medication",
               value = 0,
            width = 150),
  textInput(inputId = "c.RDZP",
               label = "Rectal diazepam",
               value = 326.37,
            width = 150),  
  textInput(inputId = "c.NMDZ",
               label = "Nasal midazolam",
               value = 11.9,
            width = 150),    
  textInput(inputId = "c.BMDZ",
               label = "Buccal midazolam",
               value = 5.79,
            width = 150),   
  textInput(inputId = "c.IMMDZ",
               label = "Intramuscular midazolam",
               value = 12.54,
            width = 150), 
  textInput(inputId = "c.NLZP",
            label = "Nasal lorazepam", 
            value = 12.28,
            width = 150)), 

  column(6, 
         tags$br(),
         tags$br(),   
         tags$br(),
         tags$br(),
         tags$br(),
         tags$br(),
         tags$strong("SEIZURE STOPPED"),
         tags$br(),
         tags$strong("(SS)"),
         tags$br(),
         tags$br(),
         tags$br(),
  # Input probabilities into the model
  textInput(inputId = "p.NomedSS",
               label = "No medication",
               value = 0.29,
            width = 150),  
  textInput(inputId = "p.RDZPSS",
               label = "Rectal diazepam",
               value = 0.75,
            width = 150),   
  textInput(inputId = "p.NMDZSS",
               label = "Nasal midazolam",
               value = 0.89,
            width = 150),   
  textInput(inputId = "p.BMDZSS",
               label = "Buccal midazolam",
               value = 0.73,
            width = 150), 
  textInput(inputId = "p.IMMDZSS",
               label = "Intramuscular midazolam",
               value = 0.88,
            width = 150), 
  textInput(inputId = "p.NLZPSS",
            label = "Nasal lorazepam",
            value = 0.79,
            width = 150))
  ),img(src = 'Figuretree.png', height = "100%", width = "100%")
  ), 
  
  mainPanel(
  ## OUTPUTS  

  column(6, offset = 1,
         # ICER table
         tags$br(),
         tags$br(),
         tags$strong("OUTPUT"),
         tags$br(),
         tags$br(),
         tags$strong("COST-EFFECTIVENESS TABLE"),
         tags$br(),
         tags$br(),  
         tableOutput("ICER"),
         tags$header("*Dominated alternatives dissappear from the table"),
         tags$br(),
         tags$header("Legend: IE: incremental effectiveness. IC: incremental cost. ICER: incremental cost-effectiveness ratio"),
         
         
         #CE graph
         tags$br(),
         tags$br(),
         tags$br(),
         tags$br(),
         tags$strong("COST-EFFECTIVENESS PLOT"),
         tags$br(),  
         tags$br(), 
         plotOutput("plotCE", width = 500, height = 300),
         tags$br(),
         tags$header("Legend: Nomed: no medication. RDZP: rectal diazepam. NMDZ: nasal midazolam. BMDZ: buccal midazolam. IMMDZ: intramuscular midazolam. NLZP: nasal lorazepam"))
)
),
tags$br(),
tags$br(),
tags$header("Ivan Sanchez Fernandez 2016. This work is copylefted under a General Public Licence (GPL)."),
tags$header("Users are fee to run, study, and modify this software and to share and distribute original or modified versions of this software.")
)







# server.R
library(shiny)
library(ggplot2)

server <- function(input, output) {
## INCREMENTAL COST EFFECTIVENESS TABLE
    output$ICER <- renderTable({
    
    # Define the values based on the inputs
    c.Nomed <- as.numeric(input$c.Nomed)
    c.RDZP <- as.numeric(input$c.RDZP)
    c.NMDZ <- as.numeric(input$c.NMDZ)
    c.BMDZ <- as.numeric(input$c.BMDZ)
    c.IMMDZ <- as.numeric(input$c.IMMDZ)
    c.NLZP <- as.numeric(input$c.NLZP)
    
    p.NomedSS <- as.numeric(input$p.NomedSS)
    p.RDZPSS <- as.numeric(input$p.RDZPSS)
    p.NMDZSS <- as.numeric(input$p.NMDZSS)
    p.BMDZSS <- as.numeric(input$p.BMDZSS)
    p.IMMDZSS <- as.numeric(input$p.IMMDZSS)
    p.NLZPSS <- as.numeric(input$p.NLZPSS)   
    
    
    
    ## Utility of outcomes
    u.SS <- 1
    u.NoSS <- 0
    
    
    ## Effectiveness into the model
    e.Nomed <- (u.SS * p.NomedSS) + (u.NoSS * (1 - p.NomedSS))
    e.RDZP <- (u.SS * p.RDZPSS) + (u.NoSS * (1 - p.RDZPSS))
    e.NMDZ <- (u.SS * p.NMDZSS) + (u.NoSS * (1 - p.NMDZSS))
    e.BMDZ <- (u.SS * p.BMDZSS) + (u.NoSS * (1 - p.BMDZSS))
    e.IMMDZ <- (u.SS * p.IMMDZSS) + (u.NoSS * (1 - p.IMMDZSS))
    e.NLZP <- (u.SS * p.NLZPSS) + (u.NoSS * (1 - p.NLZPSS))
    
    
    ######FUNCTION FOR INCREMENTAL COST EFFECTIVENESS
    
    ## Create dataframe with cost and effectiveness data
    Cost <- c(c.Nomed, c.RDZP, c.NMDZ, c.BMDZ, c.IMMDZ, c.NLZP)
    Effectiveness <- c(e.Nomed, e.RDZP, e.NMDZ, e.BMDZ, e.IMMDZ, e.NLZP)
    Names <- c("No medication", "Rectal diazepam", "Nasal midazolam", "Buccal midazolam", "Intramuscular midazolam", "Nasal lorazepam")
    rescuemeds <- data.frame(Names, Cost, Effectiveness)
    
    #Save dataframe for plot
    rescuemedsforplot <- rescuemeds
    
    rescuemeds$Cost <- as.numeric(rescuemeds$Cost)
    ## Sort by cost
    rescuemeds <- rescuemeds[order(Cost), ]
    
    
    
    ### SORT BY COST AND ELIMINATE STRONGLY DOMINATED OPTIONS    
    for (i in 1 : length(rescuemeds$Cost)) {
      
      # Calculate incremental effectiveness
      for (j in 1 : (length(rescuemeds$Cost) - 1)){
        rescuemeds$IE[1] <- rescuemeds$Effectiveness[1]
        rescuemeds$IE[j + 1] <- rescuemeds$Effectiveness[j + 1] - rescuemeds$Effectiveness[j]
      }
      
      # Identify the first row where the incremental effectiveness is negative
      firstrownegativeIE <- which (rescuemeds$IE < 0)[1]
      
      # Are there more negatives?
      nomorenegatives <- ifelse(is.na(firstrownegativeIE) == TRUE, 1, 0)
      
      
      
      if (nomorenegatives == 1) {
        break
      } else{
        ## Eliminate the first row where the incremental effectiveness is negative
        rescuemeds <- rescuemeds[- firstrownegativeIE, ]
        # Eliminate rows with NA
        rescuemeds <- rescuemeds[!is.na(rescuemeds$Names), ]
        # Renumber the rows
        rownames(rescuemeds) <- seq(length=nrow(rescuemeds))
      } 
      
    }
    # Eliminate rows with NA
    rescuemeds <- rescuemeds[!is.na(rescuemeds$Names), ]
    
    
    
    ### CALCULATE ICER AND ELIMINATE OPTIONS BY EXTENDED DOMINANCE
    for (l in 1 : length(rescuemeds$Cost)){    
      
      # Calculate incremental effectiveness
      for (j in 1 : (length(rescuemeds$Cost) - 1)){
        rescuemeds$IE[1] <- rescuemeds$Effectiveness[1]
        rescuemeds$IE[j + 1] <- rescuemeds$Effectiveness[j + 1] - rescuemeds$Effectiveness[j]
      }
      
      # Calculate incremental cost
      for (k in 1 : (length(rescuemeds$Cost) - 1)){
        rescuemeds$IC[1] <- rescuemeds$Cost[1]
        rescuemeds$IC[k + 1] <- rescuemeds$Cost[k + 1] - rescuemeds$Cost[k]
      }
      
      ## Calculate incremental cost effectiveness
      for (h in 1 : (length(rescuemeds$Cost) - 1)) {
        rescuemeds$ICER[1] <- rescuemeds$IC[1] / rescuemeds$IE[1]
        rescuemeds$ICER[h + 1] <- rescuemeds$IC[h + 1] / rescuemeds$IE[h + 1]
      }
      
      # Calculate if some ICER is higher than the next
      for (m in 1 : length(rescuemeds$Cost)) {
        rescuemeds$ICERdifference[m] <- rescuemeds$ICER[m + 1] - rescuemeds$ICER[m]
      }
      
      # Identify the first row where the incremental effectiveness is negative
      firstrownegativeICERdifference <- which (rescuemeds$ICERdifference < 0)[1]
      
      # Are there more negatives?
      nomorenegativesICERdifference <- ifelse(is.na(firstrownegativeICERdifference) == TRUE, 1, 0)
      
      
      
      if (nomorenegativesICERdifference == 1) {
        break
      } else{
        ## Eliminate the first row where the ICERdifference is negative
        rescuemeds <- rescuemeds[- firstrownegativeICERdifference, ]
        # Eliminate rows with NA
        rescuemeds <- rescuemeds[!is.na(rescuemeds$Names), ]
        # Renumber the rows
        rownames(rescuemeds) <- seq(length = nrow(rescuemeds))
      }
      
    }
    # Eliminate rows with NA
    rescuemeds <- rescuemeds[!is.na(rescuemeds$Names), ]  
    
    # Eliminate ICERdifference column
    rescuemeds <- rescuemeds[ , - 7]

    rescuemeds
  })
  
  
  
  
## PLOT  
  output$plotCE <- renderPlot({
    
    # Define the values based on the inputs
    c.Nomed <- as.numeric(input$c.Nomed)
    c.RDZP <- as.numeric(input$c.RDZP)
    c.NMDZ <- as.numeric(input$c.NMDZ)
    c.BMDZ <- as.numeric(input$c.BMDZ)
    c.IMMDZ <- as.numeric(input$c.IMMDZ)
    c.NLZP <- as.numeric(input$c.NLZP)
    
    p.NomedSS <- as.numeric(input$p.NomedSS)
    p.RDZPSS <- as.numeric(input$p.RDZPSS)
    p.NMDZSS <- as.numeric(input$p.NMDZSS)
    p.BMDZSS <- as.numeric(input$p.BMDZSS)
    p.IMMDZSS <- as.numeric(input$p.IMMDZSS)
    p.NLZPSS <- as.numeric(input$p.NLZPSS)  
    
    
    
    ## Utility of outcomes
    u.SS <- 1
    u.NoSS <- 0
    
    
    ## Effectiveness into the model
    e.Nomed <- (u.SS * p.NomedSS) + (u.NoSS * (1 - p.NomedSS))
    e.RDZP <- (u.SS * p.RDZPSS) + (u.NoSS * (1 - p.RDZPSS))
    e.NMDZ <- (u.SS * p.NMDZSS) + (u.NoSS * (1 - p.NMDZSS))
    e.BMDZ <- (u.SS * p.BMDZSS) + (u.NoSS * (1 - p.BMDZSS))
    e.IMMDZ <- (u.SS * p.IMMDZSS) + (u.NoSS * (1 - p.IMMDZSS))
    e.NLZP <- (u.SS * p.NLZPSS) + (u.NoSS * (1 - p.NLZPSS))
    
    
    ## Create dataframe with cost and effectiveness data
    Cost <- c(c.Nomed, c.RDZP, c.NMDZ, c.BMDZ, c.IMMDZ, c.NLZP)
    Effectiveness <- c(e.Nomed, e.RDZP, e.NMDZ, e.BMDZ, e.IMMDZ, e.NLZP)
    Names <- c("Nomed", "RDZP", "NMDZ", "BMDZ", "IMMDZ", "NLZP")
    rescuemeds <- data.frame(Names, Cost, Effectiveness)
    
    #Save dataframe for plot
    rescuemedsforplot <- rescuemeds    
    
         
    
    # Order factors
    rescuemedsforplot$Names <- factor(rescuemedsforplot$Names, levels = c("Nomed", "RDZP", "NMDZ", "BMDZ", "IMMDZ", "NLZP"))
    # Plot CE
    plotCE <- ggplot(data = rescuemedsforplot, aes(x = Effectiveness, y = Cost, 
                                                   color = Names)) +
      geom_point(size = 8, shape = c(15, 17, 19, 17, 15, 18)) +
      theme(panel.background = element_rect(fill = "white"), 
            axis.text = element_text(size = 18, color = "black", face = "bold"),
            axis.title = element_text(size = 24, color = "black", face = "bold"),
            axis.ticks.length = unit(0.4, "cm"), axis.ticks = element_line(size = 1.2),
            axis.line.x = element_line(color="black", size = 1.2),
            axis.line.y = element_line(color="black", size = 1.2), 
            legend.key = element_rect(fill = "white"), legend.position = "bottom") +
      scale_colour_manual(name="",  
                          values = c("Nomed"="#0076c0", "RDZP"="#a30234", "NMDZ"="#002157",
                                     "BMDZ"="#e37c1d", "IMMDZ"="#511d24", "NLZP"="#67771a")) +
      labs(x= "Effectiveness (SS)", y= "Cost ($)")
    
    plotCE
    
  })

}



# Run the app
shinyApp(ui = ui, server = server)
